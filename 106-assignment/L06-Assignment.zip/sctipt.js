function stringCounter(sentence){
    // FUNCTION CODE GOES HERE
    splited = sentence.split(" ");
    wordlength = splited.length;
    charlength = sentence.length;
    console.log("No. of Words: "+wordlength);
    console.log("No. of Chars: "+charlength);
}

// TEST CASE 1
let sentence1 = "The largest living thing on earth is a giant sequoia named General Sherman";
stringCounter(sentence1);

// TEST CASE 2
let sentence2 = "A sunset on Mars is blue";
stringCounter(sentence2);